/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jamfprocleaner;

/*
Programmer: Zachary Dorow
Programming Project 4.6
Object Oriented Programming I
Box Excercise 
 */
public class JssApiException extends Exception {
 
                private static final long serialVersionUID = 8115086578198181199L;
                private Exception e;
                private int httpResponseCode;
               
                public JssApiException(Exception e, int lastResponseCode) {
                                this.e = e;
                                this.httpResponseCode = lastResponseCode;
                }
 
                public Exception getE() {
                                return e;
                }
 
                public int getHttpResponseCode() {
                                return httpResponseCode;
                }
 
}
